create procedure insertdata100000()
  BEGIN
	declare i int default 0;
	while i<100000 do 
	insert into test(id,name) value(i+1,CONCAT('jack',CAST(i AS CHAR)));
	set i=i+1;
	end WHILE;
	end;

